#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <glpk.h>

#define N 500        // number of tasks
#define MAX_EDGES 2000  // max number of precedence constraints

typedef struct {
    int u, v; // precedence: u -> v
} Edge;

// Random PCS generator
int generate_precedences(Edge *edges, int max_edges) {
    int count = 0;
    for(int i = 0; i < N && count < max_edges; i++) {
        for(int j = i+1; j < N && count < max_edges; j++) {
            if(rand()%5 == 0) { // 20% chance of precedence
                edges[count].u = i;
                edges[count].v = j;
                count++;
            }
        }
    }
    return count;
}

int main() {
    srand(time(NULL));
    int P, D;

    printf("Enter number of processors: ");
    scanf("%d", &P);
    printf("Enter deadline (number of time units): ");
    scanf("%d", &D);

    Edge edges[MAX_EDGES];
    int num_edges = generate_precedences(edges, MAX_EDGES);

    printf("Generated PCS with %d tasks and %d precedence constraints.\n", N, num_edges);

    clock_t t0 = clock();

    // Create ILP problem
    glp_prob *lp;
    lp = glp_create_prob();
    glp_set_prob_name(lp, "PCS");
    glp_set_obj_dir(lp, GLP_MIN); // we only care about feasibility

    // Total variables: N*D (binary start time assignment)
    int num_vars = N * D;
    glp_add_cols(lp, num_vars);

    // Set binary variables x[i][t]: task i starts at time t
    for(int i = 0; i < N; i++) {
        for(int t = 0; t < D; t++) {
            int idx = i*D + t +1;
            char name[32];
            sprintf(name, "x_%d_%d", i, t);
            glp_set_col_name(lp, idx, name);
            glp_set_col_kind(lp, idx, GLP_BV);
            glp_set_obj_coef(lp, idx, 0.0);
        }
    }

    // Each task scheduled exactly once: sum_t x[i][t] = 1
    glp_add_rows(lp, N);
    for(int i=0; i<N; i++) {
        char name[32]; sprintf(name,"task_%d",i);
        glp_set_row_name(lp, i+1, name);
        glp_set_row_bnds(lp, i+1, GLP_FX, 1.0, 1.0);
        int indices[D+1];
        double values[D+1];
        for(int t=0; t<D; t++) {
            indices[t+1] = i*D + t +1;
            values[t+1] = 1.0;
        }
        glp_set_mat_row(lp, i+1, D, indices, values);
    }

    // Processor constraints: sum_i x[i][t] <= P
    glp_add_rows(lp, D);
    for(int t=0; t<D; t++) {
        char name[32]; sprintf(name,"proc_time_%d",t);
        glp_set_row_name(lp, N+t+1, name);
        glp_set_row_bnds(lp, N+t+1, GLP_UP, 0.0, P);
        int indices[N+1]; double values[N+1];
        for(int i=0; i<N; i++) {
            indices[i+1] = i*D + t +1;
            values[i+1] = 1.0;
        }
        glp_set_mat_row(lp, N+t+1, N, indices, values);
    }

    // Precedence constraints: start_u + 1 <= start_v
    glp_add_rows(lp, num_edges * D); // max rows needed
    int row_idx = N+D+1;
    for(int e=0; e<num_edges; e++) {
        int u = edges[e].u;
        int v = edges[e].v;
        for(int t1=0; t1<D; t1++) {
            int t2_start = t1+1;
            if(t2_start >= D) continue;
            int indices[3]; double values[3];
            indices[1] = u*D + t1 +1; values[1] = 1.0;
            indices[2] = v*D + t2_start +1; values[2] = -1.0;
            glp_set_row_name(lp, row_idx, "prec");
            glp_set_row_bnds(lp, row_idx, GLP_UP, -1.0, 0.0); // x_u +1 <= x_v
            glp_set_mat_row(lp, row_idx, 2, indices, values);
            row_idx++;
        }
    }

    // Solve ILP
    glp_iocp parm; glp_init_iocp(&parm);
    parm.presolve = GLP_ON;
    int ret = glp_intopt(lp, &parm);

    clock_t t1 = clock();
    double seconds = (double)(t1 - t0)/CLOCKS_PER_SEC;
    printf("ILP solved in %.4f seconds\n", seconds);

    if(ret == 0) {
        printf("Feasible schedule found!\n");
        for(int i=0; i<N; i++) {
            for(int t=0; t<D; t++) {
                int idx = i*D + t +1;
                if(glp_mip_col_val(lp, idx) > 0.5) {
                    printf("Task %d starts at time %d\n", i, t);
                    break;
                }
            }
        }
    } else {
        printf("No feasible schedule found.\n");
    }

    glp_delete_prob(lp);
    return 0;
}

